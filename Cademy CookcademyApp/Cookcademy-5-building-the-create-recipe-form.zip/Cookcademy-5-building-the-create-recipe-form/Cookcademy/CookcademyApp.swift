//
//  CookcademyApp.swift
//  Cookcademy
//
//  Created by Ben Stone on 4/19/21.
//

import SwiftUI

@main
struct CookcademyApp: App {
    var body: some Scene {
        WindowGroup {
            RecipeCategoryGridView()
        }
    }
}
